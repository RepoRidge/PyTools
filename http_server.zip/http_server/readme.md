# HTTP Server for Video Streaming

This is a simple HTTP server for video streaming. To access the video stream, please follow the instructions below.

## How to Access the Video Stream

1. Ensure you have Python installed on your system.
2. Clone or download this repository to your local machine.
3. Install the required dependencies by running:
   ```
   pip install Flask
   ```
4. Run the HTTP server by executing the following command:
   ```
   python server.py
   ```
5. Once the server is running, open your web browser and navigate to [http://127.0.0.1:5000/video](http://127.0.0.1:5000/video).

## Additional Information

- This server is built using Python and Flask, a micro web framework for Python.
- The video stream is served using simple HTTP streaming techniques.
- You may need a compatible video player in your web browser to view the stream.
- The video file being streamed is `example.mp4`.
- For any inquiries or issues, please feel free to open an issue in this repository.

Thank you for using our video streaming server!