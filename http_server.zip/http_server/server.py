from flask import Flask, send_file

app = Flask(__name__)

# Percorso del video sul server
VIDEO_FILE = 'example.mp4'

@app.route('/video')
def send_video():
    # Invia il video al client
    return send_file(VIDEO_FILE, mimetype='video/mp4')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)